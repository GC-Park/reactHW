import Banana from '../components/Banana'

const banana= () => {
  return <Banana color='yellow' fruit='Banana'/>
}

export default banana
