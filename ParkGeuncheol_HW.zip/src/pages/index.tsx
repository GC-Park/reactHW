import Apple from '../components/Apple'

const Home= () => {
  return (
    <div>
      <Apple color='red' fruit="apple" />
    </div>
  )
}

export default Home
